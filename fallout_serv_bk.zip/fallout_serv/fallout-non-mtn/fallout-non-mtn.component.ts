import { Component, OnInit } from '@angular/core';
import { config } from '../../../config';

@Component({
  selector: 'com-fallout-non-mtn',
  templateUrl: './fallout-non-mtn.component.html',
  styleUrls: ['./fallout-non-mtn.component.scss']
})
export class FalloutNonMTNComponent implements OnInit {

  ASSETS_PATH: any = config.ASSETS;
  constructor() { }

  ngOnInit() {
  }

}
