import { Component, OnInit } from '@angular/core';
import { config } from '../../../config';

@Component({
  selector: 'com-fallout-payment-unsuccessful',
  templateUrl: './fallout-payment-unsuccessful.component.html',
  styleUrls: ['./fallout-payment-unsuccessful.component.scss']
})
export class FalloutPaymentUnsuccessfulComponent implements OnInit {

  ASSETS_PATH: any = config.ASSETS;
  constructor() { }

  ngOnInit() {
  }

}
