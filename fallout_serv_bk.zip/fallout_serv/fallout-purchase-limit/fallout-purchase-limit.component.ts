import { Component, OnInit } from '@angular/core';
import { config } from '../../../config';

@Component({
  selector: 'com-fallout-purchase-limit',
  templateUrl: './fallout-purchase-limit.component.html',
  styleUrls: ['./fallout-purchase-limit.component.scss']
})
export class FalloutPurchaseLimitComponent implements OnInit {

  ASSETS_PATH: any = config.ASSETS;
  
  constructor() { }

  ngOnInit() {
  }

}
