import { Component, OnInit } from '@angular/core';
import { config } from '../../../config';

@Component({
  selector: 'com-fallout-feedback-error',
  templateUrl: './fallout-feedback-error.component.html',
  styleUrls: ['./fallout-feedback-error.component.scss']
})
export class FalloutFeedbackErrorComponent implements OnInit {

  ASSETS_PATH: any = config.ASSETS;
  
  constructor() { }

  ngOnInit() {
  }

}
