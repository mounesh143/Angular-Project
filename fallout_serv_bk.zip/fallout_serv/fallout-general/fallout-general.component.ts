import { Component, OnInit } from '@angular/core';
import { config } from '../../../config';

@Component({
  selector: 'com-fallout-general',
  templateUrl: './fallout-general.component.html',
  styleUrls: ['./fallout-general.component.scss']
})
export class FalloutGeneralComponent implements OnInit {

  ASSETS_PATH: any = config.ASSETS;
  
  constructor() { }

  ngOnInit() {
  }

}
