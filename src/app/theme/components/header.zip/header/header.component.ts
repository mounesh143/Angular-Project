import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { config } from '../../../config';
import { AngularCDRService } from '../../../plugins/angularCDR';
import { HeaderBackService } from '../../services';

@Component({
  selector: 'com-header',
  templateUrl: './header.component.html',
  styleUrls: ['../../scss/_header.scss', './header.component.scss']
})

export class HeaderComponent implements OnInit, OnChanges {
  @Input() header_text: string;
  public ASSETS_PATH: string = config.ASSETS;
  showBackToProduct = false;
  startTime: any;
  constructor(private _cdr: AngularCDRService, private _backlink: HeaderBackService) {}
  ngOnInit() {
  }
  ngOnChanges() {
    this.startTime = this._cdr.getTransactionTime(0).toString();
  }
  goBack() {
    // this._backlink.back_link()
  }
}

